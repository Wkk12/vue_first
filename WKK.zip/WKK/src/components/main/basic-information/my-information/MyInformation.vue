<template>
    <div class="MyInformation">
        <BasiclnformationPublic></BasiclnformationPublic>
        <!-- <MyIndormationChange></MyIndormationChange> -->
    </div>
</template>

<script>
import BasiclnformationPublic from "../BasiclnformationPublic.vue"
// import MyIndormationChange from "./MyIndormationChange.vue"
    export default {
        name:"MyInformation",
        components:{
            BasiclnformationPublic,
            // MyIndormationChange
        }
    }
</script>

<style lang="less" scoped>
.MyInformation{
    padding: 0px 125px;
    background: #f4f4f4;
    display: flex;
    padding-bottom: 35px;
}
</style>