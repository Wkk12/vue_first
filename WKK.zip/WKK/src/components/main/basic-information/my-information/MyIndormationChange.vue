<template>
      <div class="MainTwoRight">
                <form class="two_form" action="" v-show="num==0">
                    <ul class="one_form_nav">
                        <li v-for="(item,index) in navlist" :key=index>
                           <label> {{item.class}}</label>
                        </li>
                    </ul>
                    <ul class="one_form_input">
                        <li >
                            <p>{{name}}</p>
                        </li>
                        <li >
                            <p>{{born_data}}</p>
                        </li>
                        <li >
                            <p>{{sex}}</p>
                        </li>
                        <li  class="phone_input">
                            <p>{{phone_num}}</p>
                            <div class="yanzheng">
                                <i class="fa fa-check"></i>
                                <span>已验证</span>
                            </div>
                           
                        </li>
                        <li >
                            <p>{{email}}</p>
                            
                        </li>
                        <li >
                            <p>{{idnumber}}</p>
                        </li>
                        <li >
                            <p>{{weixin}}</p>
                        </li>
                        <li >
                            <p>{{qq}}</p>
                        </li>
                    </ul>

                    <div class="editor" @click="num=1" :class="{active:num==1}" >
                        <i class="fa fa-pencil"></i>编辑
                    </div>
                </form>
                <form class="one_form"  action="" v-show="num==1">
                    <ul class="one_form_nav">
                        <li v-for="(item,index) in navlist" :key=index>
                           <label> {{item.class}}</label>
                        </li>
                    </ul>
                    <ul class="one_form_input">
                        <li >
                            <input type="text" v-model="name">
                        </li>
                        <li >
                            <input type="text" placeholder="本项不可输入，填写完身份证信息后自动同步出生日期">
                        </li>
                        <li >
                            <select style=" width: 428px;" v-model="sex">
                                <option value="男">男</option>
                                <option value="女">女</option>
                            </select>
                        </li>
                        <li  class="phone_input">
                            <input type="text" v-model="phone_num">
                            <div class="yanzheng">
                                <i class="fa fa-check"></i>
                                <span>已验证</span>
                            </div>
                            <div class="get_code"><a href="javascript:;">获取验证码</a></div>
                        </li>
                        <li >
                            <input type="text" class="phone" v-model="email">
                        </li>
                        <li >
                            <input type="text" v-model="idnumber">
                        </li>
                        <li >
                            <input type="text" v-model="weixin">
                        </li>
                        <li >
                            <input type="text" v-model="qq">
                        </li>
                    </ul>
                        <div class="save_modify">
                                <div class="save" @click="num=0" :class="{active:num==0}">保存信息</div>
                                <div class="modify" @click="del">取消修改</div>
                        </div>
                </form>
                
            </div>
</template>

<script>
    export default {
        name:"MyIndormationChange",
        data:function(){
            return{
               num:0,
               name:"刘子熙",
               born_data:"1990年3月2日",
               sex:"男",
               phone_num:"15910578034",
               email:"xuepin@admin.com",
               idnumber:"110324199003024357",
               weixin:"13810194417",
               qq:"367722645",
               
               navlist:[
                   {class:"姓名"},
                   {class:"出生日期"},
                   {class:"性别"},
                   {class:"手机号"},
                   {class:"邮箱"},
                   {class:"身份证"},
                   {class:"微信号"},
                   {class:"QQ号"},
               ]
            }
        },
        methods:{
            del(){
                this.name==""
            }
        },
    }
</script>

<style lang="less" scoped>
.one_form .one_form_nav ,.two_form .one_form_nav{
    vertical-align: top;
    display: inline-block;
    text-align: -webkit-right;
    width: 80px;
    margin-right: 15px;
    color: #aaaaaa;
    font-size: 16px;
}

.one_form_nav li{
    border: 1px solid white;
    line-height: 45px;
    margin-bottom: 15px;
}
.two_form{
    position: relative;
}
.one_form_input{
    display: inline-block;
}
.one_form_input input ,.one_form_input select {
    width: 415px;
    height: 37px;
    border-radius: 5px ;
    padding-left: 10px;
    border: 1px solid #aaaaaa;
    font-size: 16px;
}
.phone_input{
    position: relative;
}
.yanzheng{
    position: absolute;
    width: 80px;
    top: 0;
    left: 220px;
    color: #b0d336;
}
.get_code{
    display: inline-block;
    position: absolute;
    top: 5px;
    right: 24px;
    line-height: 38px;
    padding-left: 20px;
    border-left: 1px solid #aaaaaa;
} 
.one_form_input li{
    line-height: 45px;
    margin-bottom: 17px;
}
.two_form .one_form_input p{
    height:43px;
    border-radius: 5px ;
    padding-left: 10px;
    border: 1px solid white;
}
.MainTwoRight{
    border-radius: 8px;
    background: white;
    padding-left: 35px;
    flex: 1;
    margin-top: 50px ;
    justify-content:space-between;
}
.MainTwoRight form{ 
    margin-top: 45px;
    position: relative;
}



.MainTwoRight table input,
.MainTwoRight table select{
    width: 415px;
    height: 45px;
    border: 1px solid #a3a3a3;
    border-radius: 5px;
}

.phone_mobile_validation{
    display: inline-block;
    position: relative;
}

.phone_mobile_btn{
    position: absolute;
    top: 4px;
    right: 0;
    border-left: 1px solid #a3a3a3;
    width: 160px;
    text-align: center;
    cursor: pointer;
    font-weight: bold;
}

.save_modify{
    margin-left: 100px;
}
.save,.modify{
    text-align: center;
    display: inline-block;
    width: 165px;
    line-height: 45px;
    background: #00aaff;
    color: white;
    border-radius: 15px;
}
.modify{
    margin-left: 20px;
   
}


.MainTwoRight table input,
.MainTwoRight table select{
    width: 415px;
    height: 45px;
    border: 1px solid #a3a3a3;
    border-radius: 5px;
}

.phone_mobile_validation{
    display: inline-block;
    position: relative;
}

.phone_mobile_btn{
    position: absolute;
    top: 4px;
    right: 0;
    border-left: 1px solid #a3a3a3;
    width: 160px;
    text-align: center;
    cursor: pointer;
    font-weight: bold;
}

.save_modify{
    margin-left: 100px;
}
.save,.modify{
    text-align: center;
    display: inline-block;
    width: 165px;
    line-height: 45px;
    background: #00aaff;
    color: white;
    border-radius: 15px;
}
.modify{
    margin-left: 20px;
   
}
.editor{
    position: absolute;
    right: 50px;
    top: -8px;
    color: #00a7ff;
    
}
.editor i{
    padding-right: 5px;
}

</style>