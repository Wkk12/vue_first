<template>
     <div>
            <div class="PersonalProfile_right" v-show="num==0">
                <p class="PersonalProfile_right_title">个人简介
                    <span class="clearfix" @click="num=1"><i class="fa fa-pencil"></i>编辑</span>
                </p>
                <div >
                    <p >涂磊，1977年6月10日出生于江西省南昌市，中国内地男主持人，毕业于南方冶金学院(现江西理工大学)计算机系1996级。</p>
                    <p>2004年，担任长沙人民广播电台星沙之声频道 (FM105)的主持人。2006年，转战电视节目，随后主持了长沙晚间法律节目《方圆调查》。2010年，担任青海卫视新闻脱口秀节目《嘎嘣爆米花》的嘎嘣观察员[1]。2011年，主持浙江钱江频道电视新闻时评类节目《九点半》[2]。2012年，主持了江西卫视新闻评论类节目《深度观察》[3]。2013年，担任河北卫视情感谈话节目《情感大裁判》的主持人[4]。2014年，担任天津卫视职场招聘节目《非你莫属》的主持人[5] ;同年，在天津卫视情感综艺类节目《爱情保卫战》中担任情感导师[6]。</p>
                </div>
            </div>
            <div class="AuthenticationInformation"  v-show="num==1">
                <p class="introduction_title">个人简介</p>
                <div class="introduction">
                    <p class="introduction_people">涂磊，1977年6月10日出生于江西省南昌市，中国内地男主持人，毕业于南方冶金学院(现江西理工大学)计算机系1996级。</p>
                    <p class="introduction_experience">2004年，担任长沙人民广播电台星沙之声频道 (FM105)的主持人。2006年，转战电视节目，随后主持了长沙晚间法律节目《方圆调查》。2010年，担任青海卫视新闻脱口秀节目《嘎嘣爆米花》的嘎嘣观察员[1]。2011年，主持浙江钱江频道电视新闻时评类节目《九点半》[2]。2012年，主持了江西卫视新闻评论类节目《深度观察》[3]。2013年，担任河北卫视情感谈话节目《情感大裁判》的主持人[4]。2014年，担任天津卫视职场招聘节目《非你莫属》的主持人[5] ;同年，在天津卫视情感综艺类节目《爱情保卫战》中担任情感导师[6]。</p>
                </div>
                <p class="modify_btn">
                    <a @click="num=0" href="javascript:;" class="yes">确认修改</a>
                    <a href="javascript:;" class="no">取消修改</a>
                </p>
            </div>
        </div>
</template>

<script>
    export default {
        name:"PersonalProfileRight",
        data(){
            return{
                num:0
            }
        }
    }
</script>

<style lang="less" scoped>
// 右边
.PersonalProfile_right{
    flex: 1;
    padding: 50px 40px;
}
.PersonalProfile_right_title{
     font-size: 20px;
    padding-bottom: 45px;
}
.PersonalProfile_right_title span{
    float: right;
    color: #00a7ff;
}
// .introduction{
//     font-size: 13px;
//     border: 1px solid rgba(0, 0, 0, 0.4);
//     color: #7f7f7f;
// }


// 右边第二个
.AuthenticationInformation{
    padding: 50px 40px;
    border-left: 1px solid #f8f8f8;
}
.introduction_title{
    font-size: 20px;
    padding-bottom: 30px;
}
.introduction{
    width: 380px;
    height: 390px;
    padding-left: 18px;
    padding-right: 37px;
    font-size: 16px;
    border: 1px solid rgba(0, 0, 0, 0.2);
    color: #7f7f7f;
}
.introduction_people{
    margin-top: 25px;
    margin-bottom: 30px;
}
.introduction_experience{
    margin-bottom: 30px;
}
.modify_btn{
    margin-left: 20px;
}
.yes,
.no{
    text-align: center;
    display: inline-block;
    width: 165px;
    line-height: 45px;
    background: #00aaff;
    color: white;
    border-radius: 15px;
}
.yes{
    margin-right: 20px;
    margin-top: 34px;
}
</style>