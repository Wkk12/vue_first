<template>
    <div class="AddImages">
        <img src="../../../../../assets/img/AddImages.jpg" alt="">
        <p class="positive_negative">身份证（正面） <span class="add_state">【未认证】</span> </p>
    </div>
</template>

<script>
    export default {
        name:"AddImages"
    }
</script>

<style lang="less" scoped>
.AddImages img{
    width: 180px;
    height: 125px;
    background-size: 100%;
    border: 3px dotted #c7c5c5;
}
.positive_negative{
    padding-top: 20px;
    color: #97a8be;
    font-size: 14px;
}
.add_state{
    color: #cf1900;
}
</style>