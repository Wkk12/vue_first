<template>
    <div class="AddImages">
        <img :src="props_Add.img" alt="">
        <p class="positive_negative">{{props_Add.type}} <span class="add_state">{{props_Add.CertificationStatus}}</span> </p>
    </div>
</template>

<script>
    export default {
        name:"AddImages",
        props:["props_Add"]
    }
</script>

<style lang="less" scoped>
.AddImages img{
    width: 180px;
    height: 125px;
    background-size: 100%;
    border: 3px dotted #c7c5c5;
}
.positive_negative{
    padding-top: 20px;
    color: #97a8be;
    font-size: 12px;
}
.add_state{
    color: #cf1900;
}
</style>