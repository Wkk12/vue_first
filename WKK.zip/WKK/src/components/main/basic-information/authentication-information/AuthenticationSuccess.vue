<template>
     <div class="AuthenticationSuccess">
        <div class="AuthenticationSuccess_left">
            <div class="AuthenticationSuccess_left_top">
                <AddImages class="first"  
                :props_Add="{
                     'img':oneImg,
                     'type':'身份证(正面)',
                     'CertificationStatus':'[已认证]'
                     
                 }"></AddImages>
                <AddImages
                 :props_Add="{
                     'img':twoImg,
                     'type':'身份证(反面)',
                     'CertificationStatus':'[已认证]'
                 }"></AddImages>
                <p class="prompt_information">
                    <span>请上传真实的身份证信息（正反面）<br/>照片要四角对其，如有模糊、反光、太暗、有遮挡，则不予认证</span>
                </p>
            </div>
            <div class="qualification_certification">
                 <AddImages 
                  :props_Add="{
                     'img':threeImg,
                     'type':'资质认证',
                     'CertificationStatus':'[已认证]'
                 }"></AddImages>
                  <p class="prompt_information">
                    <span>请上传能证明您专业技能的图片<br/>如:职业资格证书、加盖公章的材料证明，获奖证书等</span>
                </p>
            </div>
           
        </div>
       <PersonalProfileRight></PersonalProfileRight>
    </div>
</template>

<script>
var oneImg = require("../../../../assets/img/Modify_in_zheng.jpg")
var twoImg = require("../../../../assets/img/Modify_in_fan.jpg")
var threeImg = require("../../../../assets/img/Modify_in_jiang.jpg")

import AddImages from "./authentication-information-public/AddImages.vue"
import PersonalProfileRight from "./authentication-information-public/PersonalProfileRight.vue"

    export default {
        name:"AuthenticationSuccess",
        components:{
            AddImages,
            PersonalProfileRight
        },
        data(){
            return{
                oneImg,
                twoImg,
                threeImg
            }
        }
        
    }
   
</script>

<style lang="less" scoped>
.AuthenticationSuccess{
    border-radius: 8px;
    background: white;
    flex: 1;
    margin-top: 50px;
    justify-content: space-between;
    display: flex;
}
.AuthenticationSuccess div{
    flex: 1;
}
.AuthenticationSuccess_left{
    display: flex;
    flex-direction: column;
    text-align: center;
    border-right: 1px solid #f8f8f8;
}
.AuthenticationSuccess_left_top{
    display: flex;
    position: relative;
    margin: 50px 45px 35px 45px;
    border-bottom: 1px solid #f8f8f8;
}
.prompt_information{
    text-align: center;
    width: 100%;
    position: absolute;
    bottom: 35px;
    font-size: 14px;
    color: #c7c5c5;
}
.first{
    margin-right: 20px;
}
.qualification_certification{
    position: relative;
}

</style>