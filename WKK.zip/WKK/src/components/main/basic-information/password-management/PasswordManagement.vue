<template>
    <section class="PasswordManagement_box">
        <p class="PasswordManagement_title">登陆密码</p>
        <ul>
            <li>
                <label for="">原密码</label>
                <input type="text" name="" id="" placeholder="请输入原始密码">
            </li>
            <li>
                <label for="">新密码</label>
                <input type="text" name="" id="" placeholder="请输入新密码">
            </li>
            <li>
                <label for="">确认密码</label>
                <input type="text" name="" id="" placeholder="请再次输入新密码">
            </li>
        </ul>
        <div class="btn">
            <a href="javascript:;"><span class="sure_change_btn">确认修改</span></a>
            <a href="javascript:;"><span class="cancel_change_btn">取消修改</span></a>
        </div>
    </section>
</template>

<script>
    export default {
        name:"PasswordManagement"
    }
</script>

<style lang="less" scoped>
.PasswordManagement_box{
    background: white;
    padding-left: 50px;
    flex: 1;
    margin-top: 50px;
    border-radius: 10px;
}
.PasswordManagement_title{
    font-size: 18px;
    
    padding: 55px 50px 45px;
    margin-left: -50px;
    border-bottom: 1px solid #f0f0f0;
}
.PasswordManagement_box ul{
    margin-top: 45px;
}
.PasswordManagement_box li{
    margin-bottom: 15px;
}
.PasswordManagement_box input{
    width: 415px;
    height: 40px;
    font-size: 16px;
    padding-left: 15px;
    color: #dddddd;
    // border-radius: 5px;
}
.PasswordManagement_box label{
    margin-right: 20px;
    line-height: 40px;
    width: 75px;
  
    text-align: right;
    display: inline-block;
}
.btn{
       margin-left: 100px;
}
.btn a{
    display: inline-block;
    width: 170px;
    line-height: 45px;
    font-size: 18px;
    text-align: center;
    background: #00aaff;
    color: white;
    margin-right: 20px;
    border-radius: 10px;
 
}

</style>