<template>
<div class="write_msg_box">
        <div class="write_msg">
            <ul class="write_msg_nav" >
                <li class="write_msg_nav_userhaed">
                        <div class="userhead_box"> 
                            <img src="../../../assets/img/userhead.jpg" alt="">
                            <p class="editor_title">编辑</p>
                        </div>
                </li>
                <li class="my_msg">
                    <router-link to="/two/TwoOne" >
                        <i class="fa fa-user "></i><span>我的信息</span>
                    </router-link>
                </li>
                <li class="certification_msg">
                    <router-link to="/two/TwoTwo">
                        <i class="fa fa-check-square-o"></i><span>认证信息</span>
                    </router-link>
                </li>
                <li class="pwd_management">
                    <router-link to="/two/TwoThree">
                        <i class="fa fa-gear"></i><span>密码管理</span>
                    </router-link>
                </li>
            </ul>
            
        </div>
        <router-view></router-view>
</div>
</template>

<script>
    export default {
        name:"MyIndormationPublic"
    }
</script>

<style lang="less" scoped>
.router-link-active{
    color: #00aaff;
}
.write_msg_box{
    display: flex;
    flex: 1;
}
.write_msg{
    margin-top: 50px;
    margin-right: 20px;
    background: white;
    border-radius: 8px;
}
.write_msg_nav{
      padding: 50px 95px 270px;
      text-align: center;
}
.userhead_box{
    width: 105px;
    height: 105px;
    overflow: hidden;
    border-radius: 50%;
    color: white;
    font-size: 12px;
    position: relative;
    margin-bottom: 50px;
    cursor: pointer;
}
.editor_title{
    position: absolute;
    bottom: 0;
    width: 100%;
    height: 20px;
    padding-top: 4px;
    background: rgba(0,0,0,0.3);
}
.write_msg_nav_userhaed{
    position: relative;
}
.write_msg_nav_userhaed img{
    width: 105px;
    height: 105px;
    background-size: 100%;
    border-radius: 50%;
    margin-bottom: 50px;
}
.userhead_editor{
    position: absolute;
}
.my_msg, .certification_msg, .pwd_management{
    font-size: 20px;
    color: #666666;
    margin-bottom: 30px;
}
// .my_msg a{
//     color: #00aaff;
// }
.my_msg i,
.certification_msg i,
.pwd_management i
{
    margin-right: 3px;
}
</style>