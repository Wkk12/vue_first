<template>
    <div>
        <div class="center">
               <ul class="center_left">
                    <li class="center_left_one">
                        <img class="center_left_one_userhead" :src="data.UserHead" alt="">
                        <div>
                            <span class="center_left_one_username">{{data.userName}}</span>
                            <img class="center_left_one_usersex" :src="data.userSex"  alt="">
                        </div>
                        <div class="center_progress">
                            <span class="progress_title">信息完整度</span>
                            <span  class="progress"></span>
                            <span class="progress_level">高</span>
                        </div>
                        <div class="left_one_bottom">
                            <i class="fa fa-mobile fa-2x phone"></i>
                            <i class="fa fa-id-card-o fa-lg"></i>
                            <i class="fa fa-envelope-o fa-lg"></i>
                        </div>
                    </li>
                    <li class="center_left_two">
                        <a href="javascript:;"><p class="apply_btn clearfix">申请提现</p></a>
                        <div class="balance_box">
                            <p class="balance">账户余额</p>
                            <p class><span class="balance_num">{{data.balance_num}}</span><span class="balance_unit">元</span></p>
                        </div>
                    </li>

                    <li class="center_left_three">
                        <div class="name_certification">
                            <img src="../../../assets/img/user_msg.jpg" alt="">
                            <p class="certification_box">
                                <span>实名认证</span>
                                <span class="is_certification">[未认证]</span>
                            </p>
                        </div>
                        <div class="qualification_certification">
                            <img src="../../../assets/img/user_text.jpg" alt="">
                            <p class="certification_box">
                                <span>资质认证</span>
                                <span class="is_certification">[未认证]</span>
                            </p>
                        </div>
                    </li>
               </ul>
               <div class="center_right">
                    <div class="center_left_top">
                        <PersonalCenterPublic class="one" :props_name="{'one_title':'我上传的课程','num':'3'}"></PersonalCenterPublic>
                        <PersonalCenterPublic class="two" :props_name="{'one_title':'我的问答','num':'3'}"></PersonalCenterPublic>
                    </div>
                    <div class="center_left_bottom">
                        <p><span class="new_students">最新学员</span><span class="week_students">一周内新增25位学员</span></p>
                        <ul class="new_students_msg">
                            <li v-for="(item,index) in data.five_list" :key=index>
                                <img :src="item.twoUserHead" alt="">
                                <p>{{item.twoUser_name}}</p>
                            </li>
                            
                        </ul>
                    </div>
               </div>
               
           </div>
    </div>
</template>

<script>
let UserHead =require('../../../assets/img/userhead.jpg');
let one = require("../../../assets/img/center_bottom_one.jpg");
let two = require("../../../assets/img/center_bottom_two.jpg");
let three = require("../../../assets/img/three.jpg");
let four = require("../../../assets/img/four.jpg");
let five = require("../../../assets/img/five.jpg");

import PersonalCenterPublic from "../personal-center/personal-center-public/PersonalCenterPublic.vue"

    export default {
        name:"PersonalCenter",
        components:{
            PersonalCenterPublic
        },
        data:function(){
            return{
                data:{
                    five_list:[
                        {twoUserHead:one,twoUser_name:"杨志",},
                        {twoUserHead:two, twoUser_name:"杨静静",},
                        {twoUserHead:three, twoUser_name:"吕子秋",},
                        {twoUserHead:four, twoUser_name:"阎强",},
                        {twoUserHead:five, twoUser_name:"郭小宜",},
                        
                    ],
                    UserHead,
                    userSex:"",
                    userName:"罗密欧",
                    balance_num:248,
                    
                   
                }
            }
        },

    }
</script>

<style lang="less" scoped>
.center{
    padding: 0px 125px;
    background: #f4f4f4;
    display: flex;
    padding-top: 30px;
    padding-bottom: 35px;
}
.center_left{
    /* width: 472px; */
    /* height: 575px; */
    background: white;
    margin-right: 20px;
}
.center_left_one,
.center_left_two{
    border-bottom: 1px solid #f4f4f4;
    padding: 30px 35px;
}
.center_left_one_userhead{
    width: 90px;
    height: 90px;
    background-size: 100%;
    border-radius: 50%;
    float: left;
    margin-right: 35px;
    
}
.center_left_one_username{
    font-size: 14px;
}
.center_left_one_usersex{
    width: 16px;
    height: 22px;
    background-size: 100%;
    margin-left: 15px;
    display: inline-block;
}
.center_progress{
    margin: 10px 0 ;
    font-size: 12px;
}

.progress{
    padding-left: 142px;
    border-radius: 15px;
    background: #00aaff;
    margin:  0 10px;
    
}
.progress_level{
    color: #7ad4ff;
}
.phone{
    vertical-align: bottom;
}
.left_one_bottom i{
    line-height: 32px;
    margin-right: 10px;
}
/* 中左中 */
.center_left_two{
    padding-left: 35px;
}
.apply_btn{
    display: inline-block;
    width: 165px;
    line-height: 35px;
    color: white;
    background: #00aaff;
    border-radius: 15px;
    text-align: center;
    // float: left;
    margin-top: 15px;
}
.balance_box{
    display: inline-block;
    margin-left: 60px;
}
.balance,.balance_unit{
    font-size: 16px;
}
.balance_num{
    font-size: 32px;
    font-weight: bold;
}
/* 中左下 */
.center_left_three{
    display: flex;
    margin:  65px 35px ;
}
.name_certification{
    margin-right: 30px;
}
.certification_box{
    margin-top: 20px;
    text-align: center;
}
.name_certification img,
.qualification_certification img{
    cursor: pointer;
    width: 177px;
    height: 126px;
    background-size: 100%;
    border: 1px medium gray;
}
.is_certification{
    color: #d43202;
    font-weight: bold;

}



/* 中间右边h */
.center_right{
    flex: 1;
    display: flex;
    flex-direction: column;

}
.center_left_top{
    margin-bottom: 20px;
    display: flex;
    justify-content: space-between;
}
.center_center_right_one_box{
    margin: 35px 55px;
}
.one{
    margin-right: 20px;
}

.myclass_title{
    font-size: 18px;
}
.myclass_msg{
    margin: 35px 0 30px 0;
}
.myclass_num{
    font-size: 26px;
    font-weight: bold;
}
.myclass_unit{
    margin-left: 10px;
}
.more a{
    font-size: 16px;
    color: #9b9b9b;
}
/* 中右 下 */
.center_left_bottom{
    background: white;
    padding: 0 55px;
}
.center_left_bottom p{
    padding-top: 15px;
}
.new_students{
    font-size: 20px;
    font-weight: bold;
}
.week_students{
    float: right;
    font-size: 16px;
    color: #a6a6a6;
}
.new_students_msg{
    margin-top: 35px;
    margin-bottom: 45px;
    display: flex;
    justify-content: space-between;
}
.new_students_msg li {
    float: left;
    text-align: center;
    cursor: pointer;
}
.new_students_msg li img{
    width: 95px;
    height: 95px;
    background-size: 100%;
    border-radius: 50%;
}
.new_students_msg li p{
    margin-top: 20px;
    color: #a6a6a6;
}
</style>