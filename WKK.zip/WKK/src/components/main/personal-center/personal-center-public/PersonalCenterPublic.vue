<template>
    <div class="center_center_right_one">
            <div class="center_center_right_one_box" >
                <p class="myclass_title">{{props_name.one_title}} </p>
                <p class="myclass_msg"><span class="myclass_num">{{props_name.num}}</span><span class="myclass_unit">个</span></p>
                <p class="more"><a href="javascript:;"> 查看详情 > </a></p>
            </div>
    </div>
</template>

<script>
// let one=require('../../../../assets/img/book_bgc.jpg');
    export default {
        name:"PersonalCenterPublic",
        props:["props_name"],
        data(){
            return{ 
                
            }
        }
    }
</script>

<style lang="less" scoped>
.center_center_right_one{
    width: 375px;
    height: 280px;
    background-size: cover;
}
.center_center_right_one:first-child{
        background-image: url(../../../../assets/img/book_bgc.jpg);
}
.center_center_right_one:last-child{
    background-image: url(../../../../assets/img/egg_bgc.jpg);
}
.center_center_right_one_box{
    margin: 35px 55px;
}
.one{
    margin-right: 20px;
}


.myclass_title{
    font-size: 18px;
}
.myclass_msg{
    margin: 35px 0 30px 0;
}
.myclass_num{
    font-size: 26px;
    font-weight: bold;
}
.myclass_unit{
    margin-left: 10px;
}
.more a{
    font-size: 16px;
    color: #9b9b9b;
}
</style>