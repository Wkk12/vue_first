<template>
    <div>
      <LoginHomePage></LoginHomePage>
    </div>
</template>

<script>
import LoginHomePage from "../components/login/LoginHomePage.vue"

    export default {
        name:"Login",
        components:{
            LoginHomePage
        }
        
    }
</script>

<style lang="less" scoped>

</style>