<template>
    <div class="footer_box">
        <p class="platform">中国领先大学生成长平台◎2016 e学聘</p>
        <p>ICP备16500007号   |  联系我们 exuepin@exuepin.com  | 关于我们</p>
    </div>
</template>

<script>
export default {
    name:"Bottom"
}
</script>

<style scoped lang="less">
.footer_box{
    text-align: center;
    margin: 27px 0 25px 0;
}
.platform{
    padding-top: 10px;
}

</style>