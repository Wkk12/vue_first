<template>
    <div>
        <CenterRightOne v-for='(item,index) in list' :key=index :props_name="item"></CenterRightOne>
        
    </div>
</template>

<script>
var img= require('../../assets/img/two.jpg');
var imgtwo= require('../../assets/img/one.jpg');
import CenterRightOne from "../Center/CenterRightOne.vue"

    export default {
        data:function(){
        return{
           img,
           imgtwo,
           list:[
                {"img":img,title:"显示你的实力——面试",progress:"「进行中」",time:"3月23日 15：43",data:"免费",border:"border_bottom"},
                {"img":imgtwo,title:"微信微博新媒体一笑课程",progress:"「已结束」",time:"3月23日 15：43",data:"￥199"}
           ]
        }
    },
        name:"CenterRightOneBox",
        components:{
            CenterRightOne
        }
    }
</script>

<style lang="less" scoped>
.CenterRightOne{
    margin: 48px 0 40px;
    padding-left: 30px;
}
img{
    width: 196px;
    height: 128px;
    background-size: 100% 100%;
    float: left;
    margin-right: 25px;
    cursor: pointer;
}
.msg p{
    margin-bottom: 17px;
}
.one{
    font-size: 16px;
    font-weight: bold;
}
.two{
    font-size: 14px;
    font-weight: bolder;
    color:#5a5a5a;
}
.three{
    font-size: 12px;
    color: #cccccc;
}
.three i{
    margin-right: 5px;
}
.three_one{
    margin-right:20px ;
}
.four{
    font-size: 16px;
    color: #00aaff;
    font-weight: bolder;
}
.progress{
    color:#00aaff;
}
</style>