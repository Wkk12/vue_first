<template>
    <div class="RightDefault">
        <img src="../../assets/img/Add.jpg" alt="">
        <div>
            <p>1.不得上传未经授权的他人作品,以及色情、反动等违法视频。</p>
            <p>2.视频大小限制:不支持断点续传视频文件最大200M</p>
            <p>3、支持视频音频格式: mp4、fiv、 f4v. webm</p>
            <p>4、不支持时长小于1秒或大于10小时的视频文件，上传后将不能成功转码</p>
            <p>5、高清( 360P ): 视频分辨率>=640x360， 视频码率>=800kbps</p>
            <p>6、超清( 720P): 视频分辨率>=960x540,视频码率>=1500kbps</p>
            <p>7.蓝光(1080P) :视频分辨率>=1920x1080， 视频码率>=2500kbps</p>
        </div>
    </div>
</template>

<script>
    export default {
        name:"RightDefault"
    }
</script>

<style lang="less" scoped>
.RightDefault{
    border-radius: 8px;
    background: white;
    margin-left: 35px;
    flex: 1;
    margin-top: 50px;
    justify-content: space-between;
    // text-align: center;
    padding: 110px 270px;
}
.RightDefault img{
    padding-left: 130px;
    padding-bottom: 40px;
}
.RightDefault div{
    width: 410px;
    text-align: left;
    font-size: 12px;
    color: #d0d0d0;
}
.RightDefault div p{
    padding-bottom: 25px;
}
</style>