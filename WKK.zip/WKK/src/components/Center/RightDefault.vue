<template>
    <div class="RightDefault">

    </div>
</template>

<script>
    export default {
        name:"RightDefault"
    }
</script>

<style lang="less" scoped>
.RightDefault{
    border-radius: 8px;
    background: white;
    margin-left: 35px;
    flex: 1;
    margin-top: 50px;
    justify-content: space-between;
}
</style>