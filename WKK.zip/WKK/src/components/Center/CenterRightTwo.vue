<template>
    <div class="CenterRightOne clearfix" :class="props_name.border">
        <img :src="props_name.img" alt="" >
        <div class="msg">
            <p class="one">
                <span>{{props_name.title}}</span>
            </p>
            <p class="two">
                <span>上传时间：</span><span>{{props_name.time}}</span>
                <span class="modify_btn clearfix">修改课程</span>
                
            </p>
           
            <p class="four">{{props_name.data}}</p>
        </div>
  </div>
</template>

<script>
    export default {
        name:"CenterRightTwo",
         props:["props_name"]
    }
</script>

<style lang="less" scoped>
.CenterRightOne{
    margin: 48px 0 65px;
    padding-left: 30px;
}
img{
    width: 196px;
    height: 128px;
    background-size: 100% 100%;
    float: left;
    margin-right: 25px;
    cursor: pointer;
}
.msg p{
    margin-bottom: 17px;
}
.one{
    font-size: 16px;
    font-weight: bold;
}
.two{
    font-size: 14px;
    font-weight: bolder;
    color:#5a5a5a;
}
.three{
    font-size: 12px;
    color: #cccccc;
}
.three i{
    margin-right: 5px;
}
.three_one{
    margin-right:20px ;
}
.four{
    font-size: 16px;
    color: #00aaff;
    font-weight: bolder;
}
.progress{
    color:#00aaff;
}

.modify_btn,.cancel_btn{
    width: 165px;
    line-height: 30px;
    color: #38bdff;
    text-align: center;
    float: right;
    border: 1px solid #efefef;
    margin-right: 45px;
    border-radius: 15px;
}
.cancel_btn{
    border: none;
    display: inline-block;
}
</style>