<template>
    <div>
        <h1>CenterRightTwoBox  CenterRightTwoBox  CenterRightTwoBox </h1>
    </div>
</template>

<script>
    export default {
        name:"CenterRightTwoBox"
    }
</script>

<style lang="scss" scoped>

</style>