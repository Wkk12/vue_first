<template>
    <div>
        <div class="main_right_box_nav">
            <a href="javascript:;">
                <span class="account_login" @click="change">账号登陆</span>
            </a>
            <a href="javascript:;">
                <span class="weixin_login" @click="changes">微信登陆</span>
            </a>
        </div>
        <LoginRegistrationOne v-if="show==1" @boxChange="JT"></LoginRegistrationOne>
        <weixin v-else></weixin>
    </div>
</template>

<script>
import LoginRegistrationOne from './LoginRegistrationOne.vue'
import weixin from './weinxin.vue'

    export default {
        name:"LoginRegistration",
        props:["propsName"],
        data(){
            return{
                show:1
            }
        },
        methods:{
            JT(a){
                this.$emit("boxChangeTwo",a)
            },
            change(){
                this.show=1
            },
            changes(){
                this.show=2
            }

        },
       

        components:{
            LoginRegistrationOne,
            weixin
        },
        
    }
   
</script>

<style lang="less" scoped>
.main_right_box_nav{
    margin-top: 20px;
    display: flex;
    justify-content: space-between;
}
.main_right_box_nav span{
    line-height: 30px;
    padding: 15px 70px;
        display: inline-block;
    // border-bottom: 3px solid #ebebeb;
}
.account_login{
    color: #adc700;
    border-bottom: 3px solid #adc700;
}
.weixin_login{
    color: #939aa8;
    border-bottom: 3px solid #ebebeb;
}
.main_right_box_nav span:hover{
    color: #adc700;
    border-bottom: 3px solid #adc700;
}

</style>