<template>
    <div>
        <div class="main_right_box_nav">
            <a href="javascript:;"><span class="account_login">账号登陆</span></a>
            <a href="javascript:;"><span class="weixin_login">微信登陆</span></a> 
        </div>
        
        <div class="account_box">
            <input class="account_box_input_one" type="text" name="" id="" placeholder="手机号"><br/>
            <input class="account_box_input_two" type="text" name="" id="" placeholder="密码">
            <p class="forgot_password clearfix" @click="clickFun"><a href="javascript:;">忘记密码?</a></p>
            <p class="login_btn"><a href="javascript:;"> 登录啦！</a></p>
            <p class="registered_btn">还没有账号?<span class="please">请</span><a href="javascript:;">注册</a></p>
        </div>
    </div>
</template>

<script>
// import PhoneNumberValidation from "./PhoneNumberValidation.vue"
    export default {
        name:"LoginRegistration",
        props:["propsName"],
        data(){
            return{
                aaa:false
            }
        },

        components:{
            // PhoneNumberValidation
        },
         methods:{
             clickFun(){
                 this.$emit("boxChange",this.aaa)
             }
         }
    }
   
</script>

<style lang="less" scoped>
.main_right_box_nav{
    margin-top: 20px;
    display: flex;
    justify-content: space-between;
}
.main_right_box_nav span{
    line-height: 30px;
    padding: 15px 70px;
        display: inline-block;
    // border-bottom: 3px solid #ebebeb;
}
.account_login{
    color: #adc700;
    border-bottom: 3px solid #adc700;
}
.weixin_login{
    color: #939aa8;
    border-bottom: 3px solid #ebebeb;
}
.main_right_box_nav span:hover{
    color: #adc700;
    border-bottom: 3px solid #adc700;
}
.account_box input{
    width: 397px;
    height: 25px;
    margin-top: 55px;
}
.account_box_input_one,
.account_box_input_two
{
    padding: 2px 5px;
    border: none;
    border-bottom: 1px solid #ebebeb;
}
.forgot_password{
    float: right;
    margin-top: 15px;
}
.forgot_password a{
   color:#939aa8;
}
.login_btn{
    margin-top: 95px;
    width: 408px;
    line-height: 47px;
    background: #adc700;
    border-radius: 15px;
    color: white;
    font-size: 16px;
    text-align: center;
}
.login_btn a{
    color: #fefefc;
    display: block;
}
.registered_btn{
    margin-top: 25px;
    text-align: center;
    color: #cfcfcf;
}
.registered_btn a{
    color: #b1c90b;
}
.please{
    padding: 10px ;
}
</style>