<template>
    <div class="account_box">
        <input class="account_box_input_one" type="text" name="" id="" placeholder="手机号"><br/>
        <input class="account_box_input_two" type="text" name="" id="" placeholder="密码">
        <p class="forgot_password clearfix"><a href="javascript:;"  @click="clickFun">忘记密码?</a></p>
        <p class="login_btn"><a href="javascript:;" @click="zhuan"> 登录啦！</a></p>
        <p class="registered_btn">还没有账号?<span class="please">请</span><a href="javascript:;" @click="zhuceFun">注册</a></p>
    </div>
</template>

<script>

    export default {
        name:"LoginRegistrationOne",
         methods:{
             clickFun(){
                 this.$emit("boxChange",3)
             },
             zhuceFun(){
                 this.$emit("boxChange",2)
             },
             zhuan(){
                 this.$router.push({path:"/Main"})
             }
         }
          
    }
</script>

<style lang="less" scoped>
.account_box input{
    width: 397px;
    height: 25px;
    margin-top: 55px;
}
.account_box_input_one,
.account_box_input_two
{
    padding: 2px 5px;
    border: none;
    border-bottom: 1px solid #ebebeb;
}
.forgot_password{
    float: right;
    margin-top: 15px;
}
.forgot_password a{
   color:#939aa8;
}
.login_btn{
    margin-top: 75px;
    width: 408px;
    line-height: 47px;
    background: #adc700;
    border-radius: 15px;
    color: white;
    font-size: 16px;
    text-align: center;
}
.login_btn a{
    color: #fefefc;
    display: block;
}
.registered_btn{
    margin-top: 25px;
    text-align: center;
    color: #cfcfcf;
}
.registered_btn a{
    color: #b1c90b;
}
.please{
    padding: 10px ;
}
</style>