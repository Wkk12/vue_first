
<template>
  <div class="LoginHomePage">
    <nav>
        <a href="javascript:;">
            <img src="../../assets/img/login/login_logo.jpg" alt />
        </a>
        <a href="javascript:;">
          <!-- <span @click.prevent="comName='PhoneNumberRegistration'">注册</span>
          <span class="LoginHomePage_line"></span>
          <span @click.prevent="comName='LoginRegistration'">登录</span> -->
          <span @click.prevent="zhuce">注册</span>
          <span class="LoginHomePage_line"></span>
          <span @click.prevent="denglu">登录</span>
        </a>
    </nav>
    <main>
        <section class="main_left">
            <img src="../../assets/img/login/login_man.jpg" alt="">
            <div class="main_left_box">
                <div class="main_left_box_one">
                    <i class="fa fa-mortar-board"></i>
                    <p>我是学生</p>
                </div>
                <div class="main_left_box_two">
                    <i class="fa fa-user"></i>
                    <p>我是讲师</p>
                </div>
                <div class="main_left_box_three">
                    <i class="fa fa-user"></i>
                    <p>我是HR</p>
                </div>
            </div>
        </section>
        <section class="main_right">
            <div class="main_right_box">
                <LoginRegistration v-if="flag==1" v-on:boxChangeTwo="dataChange"></LoginRegistration>
                <PhoneNumberRegistration v-else-if="flag==2" ></PhoneNumberRegistration>
                <PhoneNumberValidation v-else-if="flag==3"  @boxChange="zhuanShouyeJie"></PhoneNumberValidation>
            </div>
        </section>
    </main> 
  </div>
</template>

<script>
import LoginRegistration from "../login/LoginRegistration.vue"
import PhoneNumberRegistration from "../login/PhoneNumberRegistration.vue"
import PhoneNumberValidation from "../login/PhoneNumberValidation.vue"

export default {
  name: "LoginHomePage",
  data(){
      return{
          comName:"LoginRegistration",
          flag:1
      }
  },
  methods:{
     zhuce(){
         this.flag=2
     },
     denglu(){
         this.flag=1
     },
     dataChange(aaa){
         this.flag=aaa
     },
     zhuanShouyeJie(a){
         this.flag=a
     }
     
  },
  components:{
    LoginRegistration,
    PhoneNumberRegistration,
    PhoneNumberValidation
  }
    
 
};
</script>

<style lang="less" scoped>
// .LoginHomePage{
//     width: 1500px;
// }
.LoginHomePage nav{
    display: flex;
    padding: 0 125px 0 150px ;
    justify-content: space-between;
    align-items: center;
    box-shadow: -1px 1px 12px 4px #e4e4e4;
}
.LoginHomePage nav a{
    
    color: #9d9d9d;
}
.LoginHomePage nav img{
    width: 275px;
    height: 55px;
    background-size: cover;
    margin:20px 0;
}
.LoginHomePage_line{
    display: inline-block;
    border-right: 1px solid;
    height: 16px;
    margin:-2px 6px;
}
.LoginHomePage main{
    display: flex;
}
.main_left{
    width: 530px;
    
    height: 844px;
    position: relative;
}
.main_left_box{
    width: 115px;
    height: 480px;
    display: flex;
    position: absolute;
    top: 140px;
    right: -3px;
    color: white;
    flex-direction: column;
    text-align: center;
}
.main_left_box div{
    
    cursor: pointer;
}
.main_left_box_one{
    flex: 1;
    padding: 30px 25px;
    background: #202421;
}
.main_left_box_two{
    flex: 2;
    padding: 90px 25px;
    background: #adc700;
}
.main_left_box_three{
    flex:1;
    padding: 30px 25px;
    background: #202421;
}
// .main_left_box div{
//     background: #202421;
// }
.main_right{
    width: 550px;
    height: 480px;
    padding-top: 140px;
}
.main_right_box{
    width: 410px;
    height: 407px;
    padding: 46px  70px 26px 70px;
    box-shadow: 2px 1px 3px 3px #e4e4e4;
}

</style>