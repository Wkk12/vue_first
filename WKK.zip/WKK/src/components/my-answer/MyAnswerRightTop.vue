<template>
        <div class="MyAnswerRightTop">
                <div class="box box_one">
                    <div class="round">√</div>
                    <span>全部</span>
                </div>
                <div class="box">
                    <div class="round">√</div>
                    <span>待处理</span>
                </div>
             <li class="questions">我要提问</li>
        </div>
</template>

<script>
    export default {
        name:"MyAnswerRightTop"
    }
</script>

<style lang="less" scoped>
.router-link-exact-active .box .round{
    background: #00aaff;
    color: white;
}
.router-link-exact-active .box span{
    color: black;
}
.MyAnswerRightTop{
    padding:40px 30px 30px 45px ;
    border-bottom: 1px solid #efefef;
    display: flex;
}

.questions{
    display: inline-block;
    width: 170px;
    line-height: 45px;
    font-size: 18px;
    text-align: center;
    background: #00aaff;
    color: white;
    margin-right: 20px;
    border-radius: 10px;
    position: absolute;
    right: 170px;
}
.box{
    display: inline-block;
    margin-right: 35px;
    line-height: 35px;
}
.box .round{
    display: inline-block;
    width: 30px;
    height: 30px;
    border-radius: 50%;
    border: 1px solid #cccccc;
    text-align: center;
    margin-right: 15px;
    color: white;
    
}
.box_one .round{
    background: #00aaff;
    
}
</style>