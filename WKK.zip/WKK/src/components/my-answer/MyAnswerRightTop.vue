<template>
        <ul class="MyAnswerRightTop">
            <li class="all">
                <input type="radio" name="aa" id="">
                <label for="">全部</label>
            </li>
             <li class="wait">
                <input type="radio" name="aa" id="">
                <label for="">待处理</label>
            </li>
             <li class="questions">我要提问</li>
        </ul>
</template>

<script>
    export default {
        name:"MyAnswerRightTop"
    }
</script>

<style lang="less" scoped>
.MyAnswerRightTop{
    padding:40px 30px 30px 45px ;
    border-bottom: 1px solid #efefef;
    display: flex;
    line-height: 45px;
}
.all label,
.wait label{
    font-size: 20px;
    vertical-align: middle;
}
.all label{
    padding-right: 75px
}
.all input,
.wait input{
    margin-right: 25px;
    width: 30px;
    height: 30px;
    vertical-align: middle;
}
.questions{
    display: inline-block;
    width: 170px;
    line-height: 45px;
    font-size: 18px;
    text-align: center;
    background: #00aaff;
    color: white;
    margin-right: 20px;
    border-radius: 10px;
    position: absolute;
    right: 170px;

}
</style>