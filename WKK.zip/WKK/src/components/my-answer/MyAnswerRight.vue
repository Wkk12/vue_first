<template>
    <div class="MyAnswerRight">
        <MyAnswerRightTop></MyAnswerRightTop>
        <MyAnswerPublic></MyAnswerPublic>
    </div>
</template>

<script>
import MyAnswerRightTop from "./MyAnswerRightTop.vue"
import MyAnswerPublic from"./MyAnswerRightBottom.vue"
    export default {
        name:"MyAnswerRight",
        components:{
            MyAnswerRightTop,
            MyAnswerPublic
        }
    }
</script>

<style lang="less" scoped>
.MyAnswerRight{
    border-radius: 8px;
    background: white;
    margin-left: 35px;
    flex: 1;
    margin-top: 50px;
    justify-content: space-between;
}
</style>