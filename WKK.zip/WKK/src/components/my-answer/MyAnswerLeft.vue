<template>
     <div class="MyAnswerLeft">
            <ul class="write_msg_nav" >
                <li class="write_msg_nav_userhaed">
                    <div class="userhead_box"> 
                        <img src="../../assets/img/userhead.jpg" alt="">
                        <p class="editor_title">编辑</p>
                    </div>
                </li>
                <li class="my_msg">
                   <!-- <a href="javascript:;" @click="aaa"> -->
                       <router-link to="/four/fourOne">
                            <i class="fa fa-user "></i><span>我的提问</span>
                        </router-link>
                        <!-- </a> -->
                </li>
                <li class="certification_msg">
                    <router-link to="/four/fourTwo">
                        <i class="fa fa-commenting-o"></i><span>我的回答</span>
                    </router-link>
                    <!-- <a href="javascript:" @click="bbb"></a> -->
                </li>
            </ul>
    </div>
</template>

<script>
    export default {
        name:"MyAnswerLeft",
        methods:{
            // aaa(){
            //     this.$router.push({path:"/four/fourOne"})
            // },
            // bbb(){
            //     this.$router.push({path:"/four/fourTwo"})
            // }
        }
    }
</script>

<style lang="less" scoped>
.MyAnswerLeft .router-link-active{
    color: #00aaff;
}
.MyAnswerLeft{
    margin-top: 50px;
    margin-right: 20px;
    background: white;
    border-radius: 8px;
}
.write_msg_nav{
      padding: 50px 95px 270px;
      text-align: center;
      
}
.userhead_box{
    width: 105px;
    height: 105px;
    overflow: hidden;
    border-radius: 50%;
    color: white;
    font-size: 12px;
    position: relative;
    margin-bottom: 50px;
    cursor: pointer;
}
.editor_title{
    position: absolute;
    bottom: 0;
    width: 100%;
    height: 20px;
    padding-top: 4px;
    background: rgba(0, 0, 0, 0.3);
}
.write_msg_nav_userhaed{
    position: relative;
}
.write_msg_nav_userhaed img{
    width: 105px;
    height: 105px;
    background-size: 100%;
    border-radius: 50%;
    margin-bottom: 50px;
}
.userhead_editor{
    position: absolute;
}
.my_msg, .certification_msg{
    font-size: 20px;
    color: #666666;
    margin-bottom: 30px;
}
// .my_msg a{
//     color: #00aaff;
// }
.my_msg i,
.certification_msg i
{
    margin-right: 3px;
}
</style>