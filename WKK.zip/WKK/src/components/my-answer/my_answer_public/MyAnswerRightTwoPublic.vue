<template>
    <div class="MyAnswerRightTwoPublic">
        <p class="MyAnswerRightTwoPublic_title">{{propsTwoName.title}}</p>
        <p class="processor_box">
        <span class="processor">{{propsTwoName.processor}}</span> 
        {{propsTwoName.msg}}
        </p>
        <p class="MyAnswerRightTwoPublic_text">
            <span>提问时间: </span>
            <span>{{propsTwoName.time}}</span> 
            <span class="HD">回答: </span>
            <span>{{propsTwoName.num}}</span>
            <span class="line"></span>
            <span>{{propsTwoName.people}}</span>
            <span>人看过</span>
            <span class="ask_people">提问者:</span>
            <span>{{propsTwoName.askPeople}}</span>
        </p>
        <p class="MyAnswerRightTwoPublic_btn">{{propsTwoName.btn}}</p>
    </div>
</template>

<script>
    export default {
        name:"MyAnswerRightTwoPublic",
        props:["propsTwoName"]
    }
</script>

<style lang="less" scoped>
.MyAnswerRightTwoPublic{
    position: relative;
    padding: 35px 20px 40px 40px;
    border-bottom: 1px solid #efefef;
}
.MyAnswerRightTwoPublic_title{
    font-size: 20px;
    font-weight: 500;
    padding-bottom: 20px;
}
.MyAnswerRightTwoPublic_text{
    font-size: 16px;
    color: #8e8e8e;
}
.MyAnswerRightTwoPublic_btn{
    width: 165px;
    line-height: 30px;
    color: #38bdff;
    text-align: center;
    float: right;
    border: 1px solid #efefef;
    margin-right: 45px;
    border-radius: 15px;
    position: absolute;
    right: 0;
    bottom: 120px;
}
.MyAnswerRightTwoPublic .HD{
    padding-left: 35px;
}
.MyAnswerRightTwoPublic_text .line{
    display: inline-block;
    border: 0.02px solid #8e8e8e;
    width: 1px;
    height: 16px;
    margin: 0 10px;
}
.processor_box{
    width: 605px;
    height: 30px;
    background: #e7e7e7;
    border: 1px solid #e7e7e7;
    border-radius: 10px;
    padding: 10px 20px;
    font-size: 13px;
    margin-bottom: 20px;
    position: relative;
}
.processor_box::before{
    content: "";
    width: 10px;
    height: 10px;
    display: inline-block;
    position: absolute;
    top: -22px;
    width: 0px;
    border-width: 6px;
    border-style: solid;
    border-color: transparent transparent #e7e7e7 transparent;
}
.ask_people{
    padding-left: 50px;
}
</style>