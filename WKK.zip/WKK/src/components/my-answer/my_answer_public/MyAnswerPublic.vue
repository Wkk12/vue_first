<template>
    <div class="MyAnswerPublic">
        <p class="MyAnswerPublic_title">{{propsName.title}}</p>
        <p class="MyAnswerPublic_text">
            <span>提问时间: </span>
            <span>{{propsName.time}}</span> 
            <span class="HD">回答: </span>
            <span>{{propsName.num}}</span>
            <span class="line"></span>
            <span>{{propsName.people}}</span>
            <span>人看过</span>
        </p>
        <p class="MyAnswerPublic_btn">{{propsName.btn}}</p>
    </div>
</template>

<script>
    export default {
        name:"MyAnswerPublic",
        props:["propsName"]
    }
</script>

<style lang="less" scoped>
.MyAnswerPublic{
    position: relative;
    padding: 40px 20px 40px 40px;
    border-bottom: 1px solid #efefef;
}
.MyAnswerPublic_title{
    font-size: 20px;
    font-weight: 500;
    padding-bottom: 20px;
}
.MyAnswerPublic_text{
    font-size: 16px;
    color: #8e8e8e;
}
.MyAnswerPublic_btn{
    width: 165px;
    line-height: 30px;
    color: #38bdff;
    text-align: center;
    float: right;
    border: 1px solid #efefef;
    margin-right: 45px;
    border-radius: 15px;
    position: absolute;
    right: 0;
    bottom: 54px;
}
.HD{
    padding-left: 35px;
}
.MyAnswerPublic_text .line{
    display: inline-block;
    border: 0.02px solid #8e8e8e;
    width: 1px;
    height: 16px;
    margin: 0 10px;
}
</style>