<template>
    <div class="MyAnswerRightBottom">
        <MyAnswerPublic
         :propsName="{'title':'中午在凡客打客服电话退货了，下午可以到么?我在北京',
         'time':'3月23日 15:43',
         'num':'0',
         'people':'91',
         'btn':'查看并处理'
        }"></MyAnswerPublic>
        <MyAnswerPublic :propsName="{'title':'中午在凡客打客服电话退货了，下午可以到么?我在北京',
         'time':'3月23日 15:43',
         'num':'0',
         'people':'91',
         'btn':'删除问题'
        }"></MyAnswerPublic>
    </div>
</template>

<script>
import MyAnswerPublic from "./my_answer_public/MyAnswerPublic.vue"
    export default {
        name:"MyAnswerRightBottom",
        components:{
            MyAnswerPublic
        }
    }
</script>

<style lang="less" scoped>

</style>