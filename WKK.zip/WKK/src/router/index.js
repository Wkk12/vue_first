import Vue from 'vue';
import VueRouter from 'vue-router';
// import Main from "../components/Main.vue"
import Center from '../components/Center/Center.vue';
import PersonalCenter from "../components/main/personal-center/PersonalCenter.vue";
import BasicInformation from "../components/main/basic-information/BasicInformation.vue";
import MyAnswer from "../components/my-answer/MyAnswer.vue"


import CenterRightOneBox from "../components/Center/CenterRightOneBox.vue";
import CenterRightTwoBox from "../components/Center/CenterRightTwoBox.vue";
import CenterRightThreeBox from "../components/Center/CenterRightThreeBox.vue"

import MyIndormationChange from "../components/main/basic-information/my-information/MyIndormationChange.vue"
// 认证信息  四个页面
// import PersonalProfile from "../components/main/basic-information/authentication-information/PersonalProfile.vue";
// import InAuthentication from "../components/main/basic-information/authentication-information/InAuthentication.vue"
// import AuthenticationFail from "../components/main/basic-information/authentication-information/AuthenticationFail.vue"
import AuthenticationSuccess from "../components/main/basic-information/authentication-information/AuthenticationSuccess.vue"

import PasswordManagement from"../components/main/basic-information/password-management/PasswordManagement.vue";

// 四
import MyAnswerRight from "../components/my-answer/MyAnswerRight.vue"
// import MyAnswerLeft from "../components/my-answer/MyAnswerLeft.vue"
import MyAnswerRightTwo from "../components/my-answer/MyAnswerRightTwo.vue"

// 课程管理默认
import RightDefault from "../components/Center/RightDefault.vue"

Vue.use(VueRouter)

  const routes = [
  {
    path: '',
    component: PersonalCenter
  },
  {
    path: '/',
    component: PersonalCenter
  },
  {
    path: '/one',
    component: PersonalCenter
  },
  {
    path: '/two',
    component: BasicInformation,
    children:[
      {
        path: '',
        component:MyIndormationChange
      },
      {
        path: '/',
        component:MyIndormationChange
      },
      {
        path:"/TwoOne",
        component:MyIndormationChange
      },
      {
        path:"/TwoTwo",
        // component:PersonalProfile,
        // component:InAuthentication
        // component:AuthenticationFail
        component:AuthenticationSuccess

        
      },
      {
        path:"/TwoThree",
        component:PasswordManagement
      },

    ]
  },
  {
    path: '/three',
    component: Center,
    children:[
      {
        path:"",
        component:CenterRightOneBox
      },
      {
        path: '/',
        component: RightDefault
      },
      {
        path:"/threeOne",
        component: CenterRightOneBox
      },
      {
        path:"/threeTwo",
        component: CenterRightTwoBox
      },
      {
        path:"/threeThree",
        component: CenterRightThreeBox
      }
    ]
  },
  {
    path:"/four",
    component:MyAnswer,
    children:[
      {
        path:"/",
        component:MyAnswerRight
      },
      {
        path:"/fourOne",
        component:MyAnswerRight
      },
      {
        path:"/fourTwo",
        component:MyAnswerRightTwo
      }
    ]
  }
  
  
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
