import Vue from 'vue';
import VueRouter from 'vue-router';
// import Main from "../components/Main.vue"
import Center from '../components/Center/Center.vue';
import PersonalCenter from "../components/main/personal-center/PersonalCenter.vue";
import BasicInformation from "../components/main/basic-information/BasicInformation.vue";


import CenterRightOneBox from "../components/Center/CenterRightOneBox.vue";
import CenterRightTwoBox from "../components/Center/CenterRightTwoBox.vue";

import MyIndormationChange from "../components/main/basic-information/my-information/MyIndormationChange.vue"
import PersonalProfile from "../components/main/basic-information/authentication-information/PersonalProfile.vue";
import PasswordManagement from"../components/main/basic-information/password-management/PasswordManagement.vue";


Vue.use(VueRouter)

  const routes = [
  {
    path: '',
    component: PersonalCenter
  },
  {
    path: '/',
    component: PersonalCenter
  },
  {
    path: '/one',
    component: PersonalCenter
  },
  {
    path: '/two',
    component: BasicInformation,
    children:[
      {
        path: '',
        component:MyIndormationChange
      },
      {
        path: '/',
        component:MyIndormationChange
      },
      {
        path:"/TwoOne",
        component:MyIndormationChange
      },
      {
        path:"/TwoTwo",
        component:PersonalProfile
        
      },
      {
        path:"/TwoThree",
        component:PasswordManagement
      },

    ]
  },
  {
    path: '/three',
    component: Center,
    children:[
      {
        path: '/',
        component: CenterRightOneBox
      },
      {
        path:"/threeOne",
        component: CenterRightOneBox
      },
      {
        path:"/threeTwo",
        component: CenterRightTwoBox
      }
    ]
  }
  
  
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
