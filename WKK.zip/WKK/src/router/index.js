import Vue from 'vue';
import VueRouter from 'vue-router';

// 首页
import Login from "../components/Login.vue"
import Main from "../components/Main.vue"

// import LoginRegistration from "../components/login/LoginRegistration.vue"
// import LoginHomePage from "../components/login/LoginHomePage.vue"
// import Main from "../components/Main.vue"
import Center from '../components/Center/Center.vue';
import PersonalCenter from "../components/main/personal-center/PersonalCenter.vue";
import BasicInformation from "../components/main/basic-information/BasicInformation.vue";
import MyAnswer from "../components/my-answer/MyAnswer.vue"

// 登录 默认
// import LoginRegistrationOne from "../components/login/LoginRegistrationOne.vue"
// import weinxin from "../components/login/weinxin.vue"

import CenterRightOneBox from "../components/Center/CenterRightOneBox.vue";
import CenterRightTwoBox from "../components/Center/CenterRightTwoBox.vue";
import CenterRightThreeBox from "../components/Center/CenterRightThreeBox.vue"

import MyIndormationChange from "../components/main/basic-information/my-information/MyIndormationChange.vue"
// 认证信息  四个页面
// import PersonalProfile from "../components/main/basic-information/authentication-information/PersonalProfile.vue";
// import InAuthentication from "../components/main/basic-information/authentication-information/InAuthentication.vue"
// import AuthenticationFail from "../components/main/basic-information/authentication-information/AuthenticationFail.vue"
import AuthenticationSuccess from "../components/main/basic-information/authentication-information/AuthenticationSuccess.vue"

import PasswordManagement from"../components/main/basic-information/password-management/PasswordManagement.vue";

// 四
import MyAnswerRight from "../components/my-answer/MyAnswerRight.vue"
// import MyAnswerLeft from "../components/my-answer/MyAnswerLeft.vue"
import MyAnswerRightTwo from "../components/my-answer/MyAnswerRightTwo.vue"

// 课程管理默认
// import RightDefault from "../components/Center/RightDefault.vue"

import FillIinformation from "../components/Center/FillIinformation.vue"
Vue.use(VueRouter)

  const routes = [
  {
    path: '',
    component: Login,
  },
  {
    path: '/Login',
    component: Login,
  },
  {
    path:"/Main",
    component:Main,
    children:[
      {
        path:'/',
        component:PersonalCenter
      },

      {
        path: '/one',
        component: PersonalCenter
      },
      {
        path: '/two',
        component: BasicInformation,
        children:[
          {
            path: '/',
            redirect: '/two/TwoOne'
    
          },
          {
            path: '',
            component:MyIndormationChange
          },
          {
            path:"/two/TwoOne",
            component:MyIndormationChange
          },
          {
            path:"/two/TwoTwo",
            // component:PersonalProfile,
            // component:InAuthentication
            // component:AuthenticationFail
            component:AuthenticationSuccess
          },
          {
            path:"/two/TwoThree",
            component:PasswordManagement
          }
    
        ]
      },
      {
        path: '/three',
        component: Center,
        children:[
          {
            path: '/',
            redirect: '/three/threeOne'
    
          },
          {
            path:"",
            component:CenterRightOneBox
          },
          {
            path:"/three/threeOne",
            component: CenterRightOneBox
          },
          {
            path:"/three/threeTwo",
            component: CenterRightTwoBox
          },
          {
            path:"/three/threeThree",
            component: CenterRightThreeBox
          }
          
        ]
      },
      {
        path:"/threeFour",
        component:FillIinformation
      },
      {
        path:"/four",
        component:MyAnswer,
        children:[
          {
            path: '/',
            redirect: '/four/fourOne'
    
          },
          {
            path:"/four/fourOne",
            component:MyAnswerRight
          },
          {
            path:"/four/fourTwo",
            component:MyAnswerRightTwo
          }
        ]
      }
    ]
  },
  
  
  
  
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
