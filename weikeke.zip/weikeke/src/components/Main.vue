<template>
    <div>
        <Header></Header>
        
        <Bottom></Bottom>
    </div>
</template>

<script>
import Header from "../components/Header/Header.vue";
import Bottom from "../components/Bottom/Bottom.vue";

    export default {
        name:"Main",
        components:{
            Header,
            Bottom,

        }
    }
</script>

<style lang="less" scoped>

</style>