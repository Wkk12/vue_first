<template>
    <div class="weinxin">
        <img src="../../assets/img/login/weixin.jpg" alt="">
    </div>
</template>

<script>
    export default {
        name:"weinxin"
    }
</script>

<style lang="less" scoped>
.weinxin img{
    margin: 0 auto;
    width: 350px;
    height: 350px;
    background-size: 100%;
    display: block;
}
</style>