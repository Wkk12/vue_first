<template>
    <div >
        <p class="PhoneNumberRegistration_title">通过手机号码注册</p>
        <div class="PhoneNumberRegistration_box">
            <input class="account_box_input_one" type="text" name="" id="" placeholder="手机号"><br/>
            <input class="account_box_input_two" type="text" name="" id="" placeholder="验证码"><br/>
            <input class="account_box_input_two" type="text" name="" id="" placeholder="密   码">
            <a href="javascript:;"><span class="get_number">获取验证码</span></a>
            <p class="submit_registered_btn">提交注册</p>
        </div>
    </div>
</template>

<script>
    export default {
        name:"PhoneNumberRegistration"
    }
</script>

<style lang="less" scoped>
.PhoneNumberRegistration_title{
    line-height: 30px;
    padding:15px 130px ;
    font-size: 16px;
    font-weight: bold;
    border-bottom: 3px solid #ebebeb;

}
.PhoneNumberRegistration_box{
    position: relative;
}
.PhoneNumberRegistration_box input{
    width: 397px;
    height: 25px;
    margin-top: 50px;
    padding: 2px 5px;
    border: none;
    font-weight: bold;
    border-bottom: 1px solid #ebebeb;
}
.PhoneNumberRegistration_box .get_number{
    position: absolute;
    right: 0;
    top: 57px;
    font-size: 13px;
    font-weight: bold;
    color: #adc700;
}
.submit_registered_btn{
    margin-top: 40px;
    width: 408px;
    line-height: 47px;
    background: #adc700;
    border-radius: 15px;
    color: white;
    font-size: 16px;
    text-align: center;
}
</style>