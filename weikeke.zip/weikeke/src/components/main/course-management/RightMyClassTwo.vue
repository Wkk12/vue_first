<template>
    <div>
         <RightMyClassTwoPublic v-for='(item,index) in list' :key=index :props_name="item"></RightMyClassTwoPublic>
    </div>
</template>

<script>
var img= require('../../../assets/img/two.jpg');
var imgtwo= require('../../../assets/img/one.jpg');
import RightMyClassTwoPublic from "./RightMyClassTwoPublic.vue"

    export default {
        name:"RightMyClassTwo",
        data:function(){
        return{
           img,
           imgtwo,
           list:[
                {"img":img,title:"显示你的实力——面试",progress:"「进行中」",time:"3月23日 15：43",data:"免费",border:"border_bottom"},
                {"img":imgtwo,title:"微信微博新媒体一笑课程",progress:"「已结束」",time:"3月23日 15：43",data:"￥199"}
           ]
        }
    },
        components:{
            RightMyClassTwoPublic
        }
    }
</script>

<style lang="scss" scoped>

</style>