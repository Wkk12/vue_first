<template>
<div class="MainTwoRight">
    <div class="MainTwoRight">
      <nav>
        <router-link to="/three/MyClass/threeOne" >
            <div class="list">
                <div class="round">√</div>
                <span>已发布课程</span>
            </div>
        </router-link>
        <router-link to="/three/MyClass/threeTwo" >
            <div class="list">
                <div class="round">√</div>
                <span>审核中课程</span>
            </div>
        </router-link>
        <router-link to="/three/MyClass/threeThree" >
            <div class="list">
                <div class="round">√</div>
                <span>未通过审核课程</span>
            </div>
        </router-link>
      </nav>
      
      
        <router-view></router-view>

    </div>
    <div>
        <!-- <RightMyClassOnePublic></RightMyClassOnePublic>
        <RightMyClassOne></RightMyClassOne> -->
    </div>
</div>
</template>

<script>
// import RightMyClassOnePublic from "./RightMyClassOnePublic.vue"
// import RightMyClassOne from "./RightMyClassOne.vue"
    export default {
        name:"RightMyClassOneBox",
        components:{
            // RightMyClassOnePublic,
            // RightMyClassOne
        }
    }
</script>

<style lang="less" scoped>
.router-link-active{
    color: #00aaff;
   
}
.router-link-exact-active .list span{
    color: black;
}
.router-link-exact-active .list .round{
    background: #00aaff;
    color:white
}
.MainTwoRight{
    border-radius: 8px;
    background: white;
    margin-left: 35px;
    flex: 1;
    margin-top: 50px ;
    justify-content:space-between;
}
nav{
    padding: 32px 40px;
    font-size: 20px;
    border-bottom: 1px solid #f0f0f0;
}
.list{
    display: inline-block;
    margin-right: 35px;
    
}
.list .round{
    display: inline-block;
    width: 30px;
    height: 30px;
    border-radius: 50%;
    border: 1px solid #cccccc;
    text-align: center;
    margin-right: 15px;
    color: white;
    
}
</style>