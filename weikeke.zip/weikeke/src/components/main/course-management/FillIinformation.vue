<template>
    <div class="FillIinformation">
        <div class="file_box">
            <p class="file_title">全民股东_201610241223.mp4</p>
            <p class="file_progress"></p>
            <p class="file_results">上传成功  100%</p>
            <a href="javascript:;" class="again">重新上传</a>
        </div>
        <ul v-show="num==0">
            <li>
                <label for="">标题</label>
                <input type="text" placeholder="请输入课程标题">
            </li>
            <li>
                <label for="">分类</label>
                <select name="" id="" >
                    <option value=""> 请选择课程分类</option>
                    <option value="1"> 1</option>
                    <option value="2"> 2</option>
                    <option value="3"> 3</option>
                </select>
            </li>
            <li class="three">
                <label for="">课程介绍</label>
                <textarea cols="2" rows="6" placeholder="请输入课程介绍"></textarea>
            </li>
            <span class="btn" @click="num=1">保存信息</span>
        </ul>
        <div class="success" v-show="num==1">
            <p class="success_img">✔</p>
            <p class="success_title">保存成功，等待审核</p>
            <p class="success_text">课程上传成功，正在进行人工审核，我们会在24小时后告知您审核结果，请耐心等候。</p>
            <p class="success_btn" @click="num=0">继续上传</p>
        </div>
    </div>
</template>

<script>
    export default {
        name:"FillIinformation",
        data(){
            return{
                num:0
            }
        }
    }
</script>

<style lang="less" scoped>
.FillIinformation{
    border-radius: 8px;
    background: white;
    margin-left: 35px;
    flex: 1;
    margin-top: 50px;
    justify-content: space-between;
}
.file_box{
    padding: 45px 40px 50px 54px;
    border-bottom: 1px solid #b6b7b8;
}
.file_box p{
    margin-bottom: 15px;
}
.file_title{
    font-size: 16px;
}
.file_progress{
    width: 100%;
    height: 7px;
    border-radius: 15px;
    background: #00aaff;
    position: relative;
}
.file_progress::after{
    content: "✔";
    width: 16px;
    line-height: 16px;
    background: #00aaff;
    border-radius: 50%;
    margin-left: 15px;
    text-align: center;
    position: absolute;
    right: -23px;
    top: -7px;
    font-size: 14px;




}
.file_results{
    font-size: 14px;
    color: #b6b7b8;
}
.again{
    float: right;
    color: #00aaff;
}
.FillIinformation ul{
    padding: 35px 40px 40px 45px;
}
.FillIinformation li{
    padding-bottom: 15px;
    display: flex;
}
.FillIinformation ul label{
    width: 70px;
    height: 15px;
    text-align: right;
    padding-right: 20px;
    color: #b6b7b8;
    display: inline-block;
    
}
.FillIinformation ul input{
    color: #b6b7b8;
    height: 45px;
    padding-left: 15px;
    flex: 1;
}
.FillIinformation ul select{
    color: #b6b7b8;
    height: 45px;
    padding-left: 15px;
    flex: 1;
}

.FillIinformation ul textarea{
    flex: 1;
    height: 178px;
    overflow: hidden;
    color: #b6b7b8;
    padding-left: 15px;
    padding-top: 15px;
}
.btn{
    text-align: center;
    display: inline-block;
    width: 165px;
    line-height: 45px;
    background: #00aaff;
    color: white;
    border-radius: 15px;
    margin-left: 90px;
}
.three label{
    vertical-align: top;
}
input::placeholder,
textarea::placeholder{
    color: #b6b7b8
}

// 
.success{
    width: 335px;
    height: 250px;
    text-align: center;
    margin: 50px auto;
}
.success_img{
    width: 85px;
    height: 85px;
    background: #00aaff;
    font-size: 66px;
    border-radius: 50%;
    margin: auto;
    margin-bottom: 25px;
}
.success_title{
    font-size: 18px;
    font-weight: bold;
    margin-bottom: 15px;
}
.success_text{
    font-size:14px;
    margin-bottom: 25px;
}
.success_btn{
    text-align: center;
    display: inline-block;
    width: 165px;
    line-height: 45px;
    background: #00aaff;
    color: white;
    border-radius: 15px;
}
</style>