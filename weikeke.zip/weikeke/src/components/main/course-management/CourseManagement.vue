<template>
    <div class="MainTwo">
        <CourseManagementLeft></CourseManagementLeft>
            <!-- <CenterRight></CenterRight> -->
            <!-- <FillIinformation></FillIinformation> -->
            <router-view></router-view>
        
        
    </div>
</template>

<script>
// import FillIinformation from "./FillIinformation"
import CourseManagementLeft from "./CourseManagementLeft";
// import CenterRight from "./CenterRight"
export default {
    name:"CourseManagement",
    components:{
        CourseManagementLeft,
        // CenterRight,
        // FillIinformation
    }
}
</script>

<style scoped lang="less">
.MainTwo{
    padding: 0px 125px;
    background: #f4f4f4;
    display: flex;
    padding-bottom: 35px;
}
</style>