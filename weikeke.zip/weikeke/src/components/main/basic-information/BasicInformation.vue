<template>
    <div>
        <MyInformation></MyInformation>
    </div>
</template>

<script>
import MyInformation from "./my-information/MyInformation.vue"
    export default {
        name:"BasicInformation",
        components:{
            MyInformation
        }

    }
</script>

<style lang="less" scoped>

</style>