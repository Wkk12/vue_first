<template>
    <div class="MyAnswerRightTwo">
        <MyAnswerRightTop></MyAnswerRightTop>
        <MyAnswerRightTwoBottom>
        </MyAnswerRightTwoBottom>
    </div>
</template>

<script>
import MyAnswerRightTop from "./MyAnswerRightTop.vue"
import MyAnswerRightTwoBottom from "./MyAnswerRightTwoBottom.vue"

    export default {
        name:"MyAnswerRightTwo",
        components:{
            MyAnswerRightTop,
            MyAnswerRightTwoBottom
        }
        
    }
</script>

<style lang="less" scoped>
.MyAnswerRightTwo{
    border-radius: 8px;
    background: white;
    margin-left: 35px;
    flex: 1;
    margin-top: 50px;
    justify-content: space-between;
}
</style>