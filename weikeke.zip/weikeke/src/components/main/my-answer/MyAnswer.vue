<template>
    <div class="MyAnswer">
        <MyAnswerLeft></MyAnswerLeft>
        <!-- <MyAnswerRight></MyAnswerRight> -->
        <!-- <MyAnswerRightTwo></MyAnswerRightTwo> -->
        <router-view></router-view>
    </div>
</template>

<script>
import MyAnswerLeft from "./MyAnswerLeft.vue"
// import MyAnswerRight from "./MyAnswerRight.vue"
// import MyAnswerRightTwo from "./MyAnswerRightTwo.vue"
    export default {
        name:"MyAnswer",
        components:{
            MyAnswerLeft,
            // MyAnswerRight
            // MyAnswerRightTwo
        }
    }
</script>

<style lang="less" scoped>
.MyAnswer{
    padding: 0px 125px;
    background: #f4f4f4;
    display: flex;
    padding-bottom: 35px;
}
</style>