<template>
    <div class="MyAnswerRightTwoBottom">
        <MyAnswerRightTwoPublic
         :propsTwoName="{
             'title':'中午在凡客打客服电话退货了，下午可以到么?我在北京',
             'processor':'CPU',
             'msg':'AMD Athlon II X4 (速龙1I四核) 640盒 装CPU (Socket AM3/3GHz/2M二级缓存/45纳米)主 板华硕(ASUS)M5A88-...',
             'time':'3月23日 15:43',
             'num':'0',
             'people':'91',
             'askPeople':'浪荡猫',
             'btn':'有追问',
             'MyAnswerRightTwoPublic_btn':'MyAnswerRightTwoPublic_btn'
             }" ></MyAnswerRightTwoPublic>
        <MyAnswerRightTwoPublic :propsTwoName="{
            'title':'中午在凡客打客服电话退货了，下午可以到么?我在北京',
             'processor':'CPU',
             'msg':'AMD Athlon II X4 (速龙1I四核) 640盒 装CPU (Socket AM3/3GHz/2M二级缓存/45纳米)主 板华硕(ASUS)M5A88-...',
             'time':'3月23日 15:43',
             'num':'0',
             'people':'91',
             'askPeople':'浪荡猫',
             'btn':'删除回答',
             'MyAnswerRightTwoPublic_btn':'MyAnswerRightTwoPublic_btn_other'
             }"  :class="bianliang"></MyAnswerRightTwoPublic>
    </div>
</template>

<script>
import MyAnswerRightTwoPublic from "./my_answer_public/MyAnswerRightTwoPublic.vue"
    export default {
        name:"MyAnswerRightTwoBottom",
        components:{
            MyAnswerRightTwoPublic
        },
        
    }
</script>

<style lang="less" scoped>

</style>