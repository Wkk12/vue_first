import Vue from 'vue'
import VueRouter from 'vue-router'
// 登录页面
import Login from "../components/Login.vue"
import Main from "../components/Main.vue"

// 首页默认  1111111
import PersonalCenter from "../components/main/my-center/PersonalCenter.vue"
// 基本信息页
import BasicInformation from "../components/main/basic-information/BasicInformation.vue"
import MyIndormationChange from "../components/main/basic-information/my-information/MyIndormationChange.vue"
// 照片验证
// import PersonalProfile from "../components/main/basic-information/authentication-information/PersonalProfile.vue";
// import InAuthentication from "../components/main/basic-information/authentication-information/InAuthentication.vue"
// import AuthenticationFail from "../components/main/basic-information/authentication-information/AuthenticationFail.vue"
import AuthenticationSuccess from "../components/main/basic-information/authentication-information/AuthenticationSuccess.vue"
// 密码管理
import PasswordManagement from "../components/main/basic-information/password-management/PasswordManagement.vue"
// 2222222222
import CourseManagement from "../components/main/course-management/CourseManagement.vue"

import RightMyClassOneBox from "../components/main/course-management/RightMyClassOneBox.vue"
import FillIinformation from "../components/main/course-management/FillIinformation.vue"
import RightMyClassOne from "../components/main/course-management/RightMyClassOne.vue"
import RightMyClassTwo from "../components/main/course-management/RightMyClassTwo.vue"
import RightMyClassThree from "../components/main/course-management/RightMyClassThree.vue"
// 44444444444444
import MyAnswer from "../components/main/my-answer/MyAnswer.vue";
import MyAnswerRight from "../components/main/my-answer/MyAnswerRight.vue";
import MyAnswerRightTwo from "../components/main/my-answer/MyAnswerRightTwo.vue"

Vue.use(VueRouter)

  const routes = [
    {
      path: '',
      component: Login,
    },
    {
      path: '/Login',
      component: Login,
    },
    {
      path:'/Main',
      component:Main,
      children:[
        {
          path:'/',
          component:PersonalCenter
        },
        {
          path: '/one',
          component: PersonalCenter
        },
        {
          path: '/two',
          component: BasicInformation,
          children:[
            {
              path: '/',
              redirect: '/two/TwoOne'
      
            },
            {
              path: '',
              component:MyIndormationChange
            },
            {
              path:"/two/TwoOne",
              component:MyIndormationChange
            },
            {
              path:"/two/TwoTwo",
              // component:PersonalProfile,
              // component:InAuthentication
              // component:AuthenticationFail
              component:AuthenticationSuccess
            },
            {
              path:"/two/TwoThree",
              component:PasswordManagement
            }
      
          ]
        },
        {
          path: '/three',
          component: CourseManagement,
          children:[
            {
              path: '/',
              redirect: '/three/MyClass'
            },
            {
              path:"",
              component:RightMyClassOneBox
            },
            {
              path:"/three/MyClass",
              component:RightMyClassOneBox,
              children:[
                {
                  path: '/',
                  redirect: '/three/MyClass/threeOne'
          
                },
                {
                  path:"",
                  component:RightMyClassOne,
                },
                {
                  path:"/three/MyClass/threeOne",
                  component:RightMyClassOne
                },
                {
                  path:"/three/MyClass/threeTwo",
                  component:RightMyClassTwo
                },
                {
                  path:"/three/MyClass/threeThree",
                  component:RightMyClassThree
                }
              ]
            },
            {
              path:"/three/Activity",
              component:FillIinformation
            }
          ]
        },
        {
          path:"/four",
          component:MyAnswer,
          children:[
            {
              path: '/',
              redirect: '/four/fourOne'
      
            },
            {
              path:"/four/fourOne",
              component:MyAnswerRight
            },
            {
              path:"/four/fourTwo",
              component:MyAnswerRightTwo
            }
          ]
        }
      ]
    }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
